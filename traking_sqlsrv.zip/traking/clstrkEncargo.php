<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of clstrkEncargo
 *
 * @author JAVSOTO
 */
require_once("../Base/DbSql.php");
require_once("../Base/fncscript.php");
require_once("../Base/clsViewData.php");

class clstrkEncargo {
    //put your code here
    
    public function lst_listar($as_encargo){
        try{
            $luo_con = new DbSql();
            
            $ls_sql="{call sp_trk_lst_encargo(?)}";
            
            $ls_parametro = array(
                array(&$as_encargo, SQLSRV_PARAM_IN));  
                        
            if(!$luo_con->createConexion()){return clsViewData::showError($luo_con->getICodeError(), $luo_con->getSMsgError());}
            
            $stid=$luo_con->sqlsrvQuery($ls_sql,$ls_parametro);
            
            if (!$stid){
                  return clsViewData::showError($luo_con->getICodeError(), $luo_con->getSMsgError());
            }
            
            $rowdata= clsViewData::viewData(sqlsrvparsearprocedure($stid),false);
             
            $luo_con->closeConexion();
             
            unset($luo_con);
             
            return $rowdata;
            
        }catch(Exception $ex){
            return clsViewData::showError($ex->getCode(), $ex->getMessage());
        }        
    }
    
    public function lst_encargodetalle($an_pai_codigo,$as_encargo){
        try{
            $luo_con = new DbSql();
            
            $ls_sql="{call sp_trk_lst_encargodetalle(?,?)}";
            
            $ls_parametro = array(
                array(&$an_pai_codigo, SQLSRV_PARAM_IN),
                array(&$as_encargo, SQLSRV_PARAM_IN));  
                        
            if(!$luo_con->createConexion()){return clsViewData::showError($luo_con->getICodeError(), $luo_con->getSMsgError());}
            
            $stid=$luo_con->sqlsrvQuery($ls_sql,$ls_parametro);
            
            if (!$stid){
                  return clsViewData::showError($luo_con->getICodeError(), $luo_con->getSMsgError());
            }
            
            $rowdata= clsViewData::viewData(sqlsrvparsearprocedure($stid),false);
             
            $luo_con->closeConexion();
             
            unset($luo_con);
             
            return $rowdata;
            
        }catch(Exception $ex){
            return clsViewData::showError($ex->getCode(), $ex->getMessage());
        }        
    }
}
