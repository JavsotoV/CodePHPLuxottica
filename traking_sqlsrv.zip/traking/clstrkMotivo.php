<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of clstrkMotivo
 *
 * @author JAVSOTO
 */
require_once("../Base/DbSql.php");
require_once("../Base/fncscript.php");
require_once("../Base/clsViewData.php");



class clstrkMotivo {
 
    public function lst_listar(){
        try{
            $luo_con = new DbSql();
            
            $ls_sql="{call sp_trk_lst_motivo}";
            
            if(!$luo_con->createConexion()){return clsViewData::showError($luo_con->getICodeError(), $luo_con->getSMsgError());}
            
            $stid=$luo_con->sqlsrvQuery($ls_sql);
            
            if (!$stid){
                return clsViewData::showError($luo_con->getICodeError(), $luo_con->getSMsgError());
            }
            
            $rowdata= clsViewData::viewData(sqlsrvparsearprocedure($stid),false);
             
            $luo_con->closeConexion();
             
            unset($luo_con);
             
            return $rowdata;
            
        }catch(Exception $ex){
            return clsViewData::showError($ex->getCode(), $ex->getMessage());
        }        
    }
}
